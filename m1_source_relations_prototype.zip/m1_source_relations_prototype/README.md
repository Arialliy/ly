# M1-U：来源关系证据归约研究原型

## 范围与状态

这是一个新写的 PyTorch 研究原型，仅实现 M1 的证据归约部分，不是完整 M1，不是 RFR 官方模块，也不是已验证有效的检测方法。没有集成或运行用户本地 DeepPro-Plus / v1.3，没有检测训练结果。

本包不包含 PDA、CUDA 扩展、视频数据集、发布权重、完整训练器或 M2。它只回答一个可测试的设计问题：在各源特征归约成一个均值以前构建来源间关系，是否比对均值做同容量的非线性变换更有用？

已在本地 PyTorch 2.10.0+cpu 环境通过 10 项合成单元测试。没有做 CUDA / AMP / RFR PDA 的集成测试，也没有测真实分辨率下的显存、耗时或检测收益。

## 接口

```python
from source_relational_reducer import SourceRelationalReducer
reducer = SourceRelationalReducer(in_channels=16, value_channels=8, hidden_channels=16)

# x_t: [B,16,H,W]
# aligned_sources: [B,K,16,H,W]，先由既有 PDA 对各个合法源完成关联。
# valid_sources: [B,K] bool，由数据和状态管理层提供，不是目标 mask。
evidence = reducer(x_t, aligned_sources, valid_sources, mode="relations")
# evidence: [B,16,H,W]
```

对照组使用同一个类与初始化：

```python
evidence = reducer(x_t, aligned_sources, valid_sources, mode="early_merge")
```

`relations` 先对每对来源构建关系，再对关系结果求均值；`early_merge` 先对源值求均值，再用相同关系网络处理这个均值的两个副本。代码刻意保留相同的来源对循环与关系网络调用次数，便于同计算路径先导对照。该控制不是推理加速实现。

## 数学定义

设 v_j = tanh(Conv1x1(A_j))，16→8 通道，所有来源共享权重。

- 内容摘要：mu = mean_j(v_j)。
- 对称关系描述：d_jk = concat(v_j+v_k, abs(v_j-v_k), v_j*v_k)。
- 关系网络：Conv1x1(24→16) → GELU → Conv1x1(16→8)。
- 关系摘要：r = mean_{j<k}(relation(d_jk))，只计算有效来源对。
- 输出：E = concat(mu, r)，16 通道。

没有历史时，内容摘要采用当前输入投影，关系摘要为零。有且仅有一个历史来源时，关系摘要为零。没有把当前帧伪造为第二个历史来源。

两半输出均为可学习特征，不是目标概率、来源可靠性或经过校准的不确定性。采用 tanh 是本原型的数值有界设计，不是检测阈值。

这是一种来源集合关系，不编码源帧排列或速度；源顺序交换原则上不改变输出。来源不同不代表其信息统计独立，尤其原前端含时间卷积。不能据此宣称独立证据相乘或平方根信噪比提升。

## 接入完整 M1 的必要合同

1. 既有状态层负责同视频、同合法窗口、源索引严格早于当前索引的检查与唯一来源检查；本归约器没有元数据，不能替代这些检查。
2. 只读取既定容量与保留规则下的来源，不增加原始观测权限。
3. 需要逐源关联结果，不能从已经合成的 E 逆向拆出真实来源。若 v1.3 不暴露逐源内容，这是一项新的状态适配，必须登记，不应称为原实现不变。
4. 不应在输入本归约器前先做 TSFM 的当前—历史置信式调制并抹掉来源差异，再声称测试了“关系构建先于归约”。RFR 原 TSFM 保留为母方法控制，本候选替换的是证据归约，不是在 TSFM 后叠加修正。
5. 既有源内容保存规则保持；本归约器不将输出 E 写回历史库。
6. `valid` 只表示来源是否可访问。它不推断 PDA 采样是否越界或对应是否正确。几何有效性需由原关联实现单独核查。
7. 训练时不要在 aligned_sources 与本模块之间 detach。窗口外隔离和登记的截断训练策略仍需由完整训练器处理。
8. Current 控制在 PDA 之前用当前特征替换历史源内容，保持同样的合法槽位时序模板和计算路径。重复占位不被解释为真实多源证据。
9. 输入和输出时间索引仍需服从原 TPro 的映射；不默认 seqlen 与 out_len 相等。
10. 原损失、0.5 阈值、窗口融合、匹配、训练曝光和 baseline 更新权限须登记；不在本实验同时更改。

## 训练组建议

先用原简单读取 H_simple = H0 + W_out(concat(X,E)) 接回原预测头。

- Current + relations。
- History + early_merge。
- History + relations。

另保留发布 baseline 与 RFR/v1.3 母方法参照；旧训练结果只有在配置匹配时才视作同条件比较。已有 Current / History × 简单读取 / M2 的完整系统设计不变。

上述三组不是要求 M1 独立恢复成功才允许开发 M2。接口和梯度测试通过后，M2 可以接通。M1 的历史独有贡献最终可在完整系统中检验。

## 成本

默认归约器共 672 个可训练参数，但每个时刻对 K 个来源执行 K(K-1)/2 次全分辨率关系网络，参数少不代表运算少。单个来源对的两层 1x1 卷积是每像素约 24*16 + 16*8 = 512 次乘加，不含激活、描述符、源投影、PDA 或其他分支。

先在现有 K、实际 H/W/T 上测量再训练。K<2 时无法检验此跨来源关系假说；不应为了运行该假说而暗中增加已固定容量。代码没有实现按需降低 K、抽样来源对、CUDA 加速或自动分块。

## 测试

```bash
python test_source_relational_reducer.py
```

测试包括形状、空历史、单来源、无效槽位隔离（含 NaN padding）、全无效回退、来源置换不变、相同来源下两种模式等价、梯度传播、同均值不同关系的构造例子、参数检查。

“同均值不同关系”测试将关系网络显式替换为乘积算子，只证明表示能够区分该构造情形，不证明随机初始化或训练后的网络实际识别目标。

## 参考代码与原型之间的关系

以下为公开参考，不是本原型的检测效果依据。没有复制其完整网络或训练监督。

- RFR，TGRS 2025：`codes/model/RFR_framework.py`，`RFR.forward_train` / `PDA` / `TSFM`。直接关联算子参照与母方法控制。
  https://github.com/XinyiYing/RFR
  https://raw.githubusercontent.com/XinyiYing/RFR/main/codes/model/RFR_framework.py
- TRN，ECCV 2018：`TRNmodule.py`，`RelationModuleMultiScale`。借鉴“分别建立帧集合关系，再聚合”的组织原则；本原型是稠密、对称、仅成对关系，并非官方 TRN 分类模块移植。
  https://github.com/zhoubolei/TRN-pytorch
  https://raw.githubusercontent.com/zhoubolei/TRN-pytorch/master/TRNmodule.py
- STCN，NeurIPS 2021：`model/network.py` / `inference_memory_bank.py`。借鉴关联、内容和状态管理的接口分离；不使用其依赖 mask 的 value encoder。
  https://github.com/hkchengrex/STCN
- BasicVSR++，CVPR 2022：`mmedit/models/backbones/sr_backbones/basicvsr_pp.py`。作为传播结构与对齐机制分别控制的参考；本轮不新增 SPyNet 或完整二阶双向传播。
  https://github.com/ckkelvinchan/BasicVSR_PlusPlus
- TEP-SAM，ICML 2026：概念近邻和后续比较方法；其时序差异建模和辅助 mask 监督不在本原型中复刻。
  https://arxiv.org/abs/2606.27655
  https://github.com/cdh8285/TEP-SAM
- DeepPro-Plus：原接口参照，未经本地完整集成。
  https://raw.githubusercontent.com/TinaLRJ/DeepPro/main/networks/models/DeepPro-Plus.py

这些链接指向可变主分支。正式实验应自行登记实际使用的 commit、配置和权重哈希，不能将本次网页核对等同于已固定上游版本。
