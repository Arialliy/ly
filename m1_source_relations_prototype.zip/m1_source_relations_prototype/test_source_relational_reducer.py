"""Synthetic implementation tests; none measure detection accuracy."""
import unittest
import torch
from torch import nn
from source_relational_reducer import SourceRelationalReducer


class ProductOnly(nn.Module):
    def forward(self, descriptor):
        return descriptor[:, descriptor.shape[1] * 2 // 3:]


class TestReducer(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(19)
        self.net = SourceRelationalReducer()
        self.x = torch.randn(2, 16, 5, 7)
        self.a = torch.randn(2, 4, 16, 5, 7)

    def test_shape_and_finite(self):
        y = self.net(self.x, self.a)
        self.assertEqual(tuple(y.shape), (2, 16, 5, 7))
        self.assertTrue(torch.isfinite(y).all())

    def test_empty_memory(self):
        y = self.net(self.x, self.a[:, :0])
        torch.testing.assert_close(y[:, :8], self.net.value(self.x))
        self.assertEqual(y[:, 8:].count_nonzero().item(), 0)

    def test_single_source_no_pair_relation(self):
        valid = torch.tensor([[True, False, False, False], [False, False, True, False]])
        y = self.net(self.x, self.a, valid)
        self.assertEqual(y[:, 8:].count_nonzero().item(), 0)

    def test_padding_invariance_including_nan(self):
        valid = torch.tensor([[True, True, False, False], [True, True, False, False]])
        changed = self.a.clone()
        changed[:, 2:] = float('nan')
        torch.testing.assert_close(self.net(self.x, self.a, valid), self.net(self.x, changed, valid))

    def test_all_invalid_fallback(self):
        valid = torch.zeros(2, 4, dtype=torch.bool)
        y = self.net(self.x, self.a, valid)
        torch.testing.assert_close(y, self.net(self.x, self.a[:, :0]))

    def test_source_permutation(self):
        valid = torch.tensor([[True, True, True, False], [True, False, True, True]])
        permutation = torch.tensor([2, 0, 3, 1])
        torch.testing.assert_close(self.net(self.x, self.a, valid), self.net(self.x, self.a[:, permutation], valid[:, permutation]))

    def test_identical_sources_modes_coincide(self):
        repeated = self.a[:, :1].expand(-1, 4, -1, -1, -1)
        torch.testing.assert_close(self.net(self.x, repeated, mode='relations'), self.net(self.x, repeated, mode='early_merge'))

    def test_gradient_and_invalid_source_isolation(self):
        a = self.a.clone().requires_grad_()
        valid = torch.tensor([[True, True, True, False], [True, True, True, False]])
        self.net(self.x, a, valid).square().mean().backward()
        self.assertGreater(a.grad[:, :3].abs().sum().item(), 0)
        self.assertEqual(a.grad[:, 3].count_nonzero().item(), 0)
        for p in self.net.parameters():
            self.assertIsNotNone(p.grad)
            self.assertTrue(torch.isfinite(p.grad).all())
            self.assertGreater(p.grad.abs().sum().item(), 0)

    def test_equal_mean_distinct_cross_source_relation(self):
        # A deliberately specified operator checks expressiveness, not learning.
        net = SourceRelationalReducer(in_channels=8)
        net.value = nn.Identity()
        net.relation = ProductOnly()
        current = torch.zeros(1, 8, 1, 1)
        isolated = torch.tensor([0.9, 0., 0.]).reshape(1, 3, 1, 1, 1).expand(1, 3, 8, 1, 1)
        repeated = torch.full_like(isolated, 0.3)
        yi = net(current, isolated)
        yr = net(current, repeated)
        torch.testing.assert_close(yi[:, :8], yr[:, :8])
        torch.testing.assert_close(yi[:, 8:], torch.zeros_like(yi[:, 8:]))
        torch.testing.assert_close(yr[:, 8:], torch.full_like(yr[:, 8:], 0.09))
        torch.testing.assert_close(net(current, isolated, mode='early_merge'), net(current, repeated, mode='early_merge'))

    def test_validation(self):
        with self.assertRaises(ValueError):
            self.net(self.x, self.a, mode='other')
        with self.assertRaises(ValueError):
            self.net(self.x, self.a, torch.ones(2, 4))


if __name__ == '__main__':
    torch.set_num_threads(1)
    unittest.main(verbosity=2)
